**Where are the robots Web Exploit Writeups:**

1.  Launch instance.

2.  Copy the link provided and paste It in your browser and it will
    direct u to a website.

3.  Now, the hint asked, what part of the website could tell you where
    the creator doesn't want me to look. So first, I tried to inspect
    the page, but unfortunately, there was no flag.

4.  I searched the internet of possible things to do, and I encountered
    a file named **robots.txt** which is said that it tells search
    engines crawlers which URL crawlers can access my website.

5.  So, what I did is that, I go to the URL of the website and I added
    robots.txt in the url and it directed me to another page.

![](./image1.png){width="6.5in" height="3.6041666666666665in"}

6.  ![](./image2.png){width="6.5in" height="2.53125in"}There is a
    disallow word and it made me curious because the hint said its where
    the creator doesn't want me to look, so what I did is that I copied
    the url beside the disallow and I pasted in on the original url of
    the page and from there, the flag is displayed replacing the welcome
    word.
