**[WEB EXPLOIT: WebDecode]{.underline}**

1.  Launch the instance first, then go to the hints and click hint
    number 1 and click the highlighted word "here" and it directs u to a
    webpage.

![](./image1.png){width="6.5in" height="3.65625in"}

2.  ![](./image2.png){width="6.5in" height="3.65625in"}Then, I
    tried to click those home, about and contact words above the webpage
    and one directed me to another page which is the **about**
    navigation.

3.  Inspect that webpage using web inspector and u can find a suspicious
    set of characters.

![](./image3.PNG){width="5.781944444444444in"
height="4.698113517060367in"}

4.  ![](./image4.png){width="6.5in" height="3.65625in"}Highlight
    and copy those characters and go to cyberChef to decode those
    characters. Then choose FROM BASE 64 and it will convert those
    characters into a flag.
